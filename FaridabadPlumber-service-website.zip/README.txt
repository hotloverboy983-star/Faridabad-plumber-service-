GitHub Pages upload:
1. Put index.html in the repository root.
2. Put the images folder beside index.html.
3. In GitHub: Settings > Pages > Deploy from branch > main > /(root) > Save.
4. Website URL: https://FaridabadPlumber.github.io/service/
